package websocket.v2;

public class MessageDao {
}
