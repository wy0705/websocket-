package websocket.v2;

public enum MessageType {

    USER_ADD,
    CHANGE_NAME,
    USER_LEAVE,
    CHAT_MSG;
}
