package proxyrpc;

public interface HelloService {

    void hello(String msg);
}
